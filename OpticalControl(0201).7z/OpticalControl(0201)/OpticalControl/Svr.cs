﻿using AUO.SubSystemControl;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OpticalControl
{

    public partial class MainForm
    {
        private CSubSystemDispatcher Svr;
        private bool IsGetRequest = false;

        private void Svr_Init()
        {
            if (Svr != null)
            {
                Svr.StopListen();
                Svr.Disconnect();
                Label Ctrl = LabelSvr;
                Ctrl.Invoke(new Action(() => Ctrl.BackColor = Color.Gray));
            }

            Svr = new CSubSystemDispatcher();

            Svr.RemoteConnectComing -= Svr_RemoteConnectComing;
            Svr.RemoteDisconnect -= Svr_RemoteDisconnect;
            Svr.RemoteControl -= Svr_RemoteControl;
            Svr.ReceiveOccurError -= Svr_ReceiveOccurError;

            Svr.RemoteConnectComing += Svr_RemoteConnectComing;
            Svr.RemoteDisconnect += Svr_RemoteDisconnect;
            Svr.RemoteControl += Svr_RemoteControl;
            Svr.ReceiveOccurError += Svr_ReceiveOccurError;

            try
            {
                string IP = SD.Svr_IP;
                int Port = SD.Svr_Port;

                Svr.CreateListener(IP, Port);
                Svr.StartListen();

                SaveLog($"Server Listen Open - {IP}:{Port}");
            }
            catch (Exception ex)
            {
                SaveLog($"Server Listen Error - {ex.Message}", true);
            }
        }

        private void SvrClose()
        {
            if (Svr != null)
            {
                Svr.StopListen();
                Svr.Disconnect();
                Label Ctrl = LabelSvr;
                Ctrl.Invoke(new Action(() => Ctrl.BackColor = Color.Gray));

            }
        }

        private void Svr_RemoteDisconnect()
        {
            Label Ctrl = LabelSvr;
            Ctrl.Invoke(new Action(() => Ctrl.BackColor = Color.Gray));
        }

        private void Svr_RemoteConnectComing()
        {
            Label Ctrl = LabelSvr;
            Ctrl.Invoke(new Action(() => Ctrl.BackColor = Color.Green));
        }

        private void Svr_ReceiveOccurError(string ErrMessage)
        {
            SaveLog("Server Error - " + ErrMessage);
        }

        private void Svr_RemoteControl(CRequest Request)
        {
            if (!IsGetRequest)
            {
                IsGetRequest = true;

                Thread MainThread = new Thread(new ParameterizedThreadStart(MainFlow));
                MainThread.Start(Request);
            }
        }

        private void MainFlow(object GetRequest)
        {
            CRequest Request = (CRequest)GetRequest;
            FlowStep Step = FlowStep.CheckType;
            string[] GetParam =
            {
                Request.Command,
                Request.Param1,
                Request.Param2,
                Request.Param3,
                Request.Param4,
                Request.Param5,
                Request.Param6,
                Request.Param7,
                Request.Param8,
                Request.Param9
            };

            eResponseResult Result = eResponseResult.OK;
            string[] SendParam = new string[10];

            TimeManager TM = new TimeManager();
            TM.SetDelay(10000);

            while (IsGetRequest)
            {
                if (TM.IsTimeOut())
                {
                    IsGetRequest = false;
                    SaveLog($"### Flow Timeout");
                }

                switch (Step)
                {
                    case FlowStep.CheckType:
                        {
                            for (int i = 1; i <= 9; i++)
                            {
                                SendParam[i] = "";
                            }

                            string RequestStr = $"{GetParam[0]}";

                            for (int i = 1; i <= 9; i++)
                            {
                                if (GetParam[i].Trim().Length > 0)
                                    RequestStr += $",{GetParam[i]}";
                            }

                            SaveLog($"### Get Request : {RequestStr}");

                            switch (GetParam[0])
                            {
                                case "WDI_AF":
                                    Step = FlowStep.WDI_AF_CheckCMD;
                                    break;

                                case "WDI_LED":
                                    Step = FlowStep.WDI_LED_CheckCMD;
                                    break;

                                case "DARK_FIELD":
                                    Step = FlowStep.Dark_Field_CheckCMD;
                                    break;

                                case "REVO":
                                    Step = FlowStep.Revo_CheckCMD;
                                    break;                                    

                                default:
                                    SaveLog("Command Match Fail", true);
                                    Result = eResponseResult.ERR;
                                    SendParam[9] = "Command Match Fail";
                                    Step = FlowStep.SendResponse;
                                    break;

                            }
                        }
                        break;

                    #region WDI AF

                    case FlowStep.WDI_AF_CheckCMD:
                        {
                            switch (GetParam[1])
                            {
                                case "Home":
                                    Step = FlowStep.WDI_AF_Home;
                                    break;

                                case "Abs_Move":
                                    Step = FlowStep.WDI_AF_Abs_Move;
                                    break;

                                case "AF_On":
                                    Step = FlowStep.WDI_AF_AF_On;
                                    break;

                                case "AF_Off":
                                    Step = FlowStep.WDI_AF_AF_Off;
                                    break;

                                case "Read_Pos":
                                    Step = FlowStep.WDI_AF_Read_Pos;
                                    break;

                                case "Set_Substrate":
                                    Step = FlowStep.WDI_AF_Set_Substrate;
                                    break;

                                case "Get_Substrate":
                                    Step = FlowStep.WDI_AF_Get_Substrate;
                                    break;

                                default:
                                    SaveLog("Command Match Fail", true);
                                    Result = eResponseResult.ERR;
                                    SendParam[9] = "Command Match Fail";
                                    Step = FlowStep.SendResponse;
                                    break;
                            }
                        }
                        break;

                    case FlowStep.WDI_AF_Home:
                        {
                            WdiRtn rtn = WDI_AF_Ctrl.WdiOff(true);
                            Result = (!rtn.ErrorOccure) ? eResponseResult.OK : eResponseResult.ERR;
                            Step = FlowStep.SendResponse;
                        }
                        break;

                    case FlowStep.WDI_AF_Abs_Move:
                        {
                            WdiRtn rtn = WDI_AF_Ctrl.WdiOff();

                            if (!rtn.ErrorOccure)
                            {
                                double Pos = 0;
                                bool ConvertOK = double.TryParse(GetParam[2], out Pos);

                                if (!ConvertOK)
                                {
                                    SaveLog("String Convert To Double Fail", true);
                                    Result = eResponseResult.ERR;
                                    SendParam[9] = "String Convert To Double Fail";
                                    Step = FlowStep.SendResponse;
                                    break;
                                }

                                rtn = WDI_AF_Ctrl.Move(AFzMoveType.ABS, Pos);
                                Result = (!rtn.ErrorOccure) ? eResponseResult.OK : eResponseResult.ERR;
                            }
                            else
                            {
                                Result = eResponseResult.ERR;
                            }
                            Step = FlowStep.SendResponse;
                        }
                        break;

                    case FlowStep.WDI_AF_AF_On:
                        {
                            int Pos = 0;
                            int LimitUpper = 0;
                            int LimitLower = 0;
                            int MoveDelay = SD.WDI_AF_MoveDelay;

                            bool ConvertOK_Pos = int.TryParse(GetParam[2], out Pos);
                            bool ConvertOK_LimitU = int.TryParse(GetParam[3], out LimitUpper);
                            bool ConvertOK_LimitL = int.TryParse(GetParam[4], out LimitLower);

                            if (!ConvertOK_Pos || !ConvertOK_LimitU || !ConvertOK_LimitL)
                            {
                                SaveLog("String Convert To Int Fail", true);
                                Result = eResponseResult.ERR;
                                SendParam[9] = "String Convert To Double Fail";
                                Step = FlowStep.SendResponse;
                                break;
                            }

                            WdiRtn rtn = WDI_AF_Ctrl.WdiOn(Pos, MoveDelay, LimitUpper, LimitLower);
                            Result = (!rtn.ErrorOccure) ? eResponseResult.OK : eResponseResult.ERR;
                            Step = FlowStep.SendResponse;
                        }
                        break;

                    case FlowStep.WDI_AF_AF_Off:
                        {
                            WdiRtn rtn = WDI_AF_Ctrl.WdiOff();
                            Result = (!rtn.ErrorOccure) ? eResponseResult.OK : eResponseResult.ERR;
                            Step = FlowStep.SendResponse;
                        }
                        break;

                    case FlowStep.WDI_AF_Read_Pos:
                        {
                            double Pos = 0;
                            WdiRtn rtn = WDI_AF_Ctrl.Read_Pos(ref Pos);
                            Result = (!rtn.ErrorOccure) ? eResponseResult.OK : eResponseResult.ERR;
                            SendParam[1] = (!rtn.ErrorOccure) ? $"{Pos}" : "";
                            Step = FlowStep.SendResponse;
                        }
                        break;

                    case FlowStep.WDI_AF_Set_Substrate:
                        {
                            short Substrate = Convert.ToInt16(GetParam[2]);
                            WdiRtn rtn = WDI_AF_Ctrl.SetSubStrate(Substrate);
                            Result = (!rtn.ErrorOccure) ? eResponseResult.OK : eResponseResult.ERR;
                            Step = FlowStep.SendResponse;
                        }
                        break;

                    case FlowStep.WDI_AF_Get_Substrate:
                        {
                            short Substrate = -1;
                            WdiRtn rtn = WDI_AF_Ctrl.GetSubStrate(ref Substrate);
                            Result = (!rtn.ErrorOccure) ? eResponseResult.OK : eResponseResult.ERR;
                            SendParam[1] = (!rtn.ErrorOccure) ? $"{Substrate}" : "";
                            Step = FlowStep.SendResponse;
                        }
                        break;

                    #endregion 

                    #region WDI LED

                    case FlowStep.WDI_LED_CheckCMD:
                        {
                            switch (GetParam[1])
                            {
                                case "Set_DC_Mode":
                                    Step = FlowStep.WDI_LED_Set_Mode;
                                    break;

                                case "Set_PulseFollow_Mode":
                                    Step = FlowStep.WDI_LED_Set_Mode;
                                    break;

                                case "Off":
                                    Step = FlowStep.WDI_LED_Off;
                                    break;

                                default:
                                    SaveLog("Command Match Fail", true);
                                    Result = eResponseResult.ERR;
                                    SendParam[9] = "Command Match Fail";
                                    Step = FlowStep.SendResponse;
                                    break;
                            }
                        }
                        break;

                    case FlowStep.WDI_LED_Set_Mode:
                        {
                            int Brightness = 0;
                            bool ConvertOK = int.TryParse(GetParam[2], out Brightness);

                            if (!ConvertOK)
                            {
                                SaveLog("String Convert To Int Fail", true);
                                Result = eResponseResult.ERR;
                                SendParam[9] = "String Convert To Double Fail";
                                Step = FlowStep.SendResponse;
                                break;
                            }

                            int Mode = (GetParam[1] == "Set_DC_Mode") ? 0 : 1;
                            WDI_LED.SetMode(Mode, Brightness);
                            Thread.Sleep(10);
                            Step = FlowStep.WDI_LED_CheckFinish;
                        }
                        break;

                    case FlowStep.WDI_LED_Off:
                        {
                            WDI_LED.TurnOff();
                            Thread.Sleep(10);
                            Step = FlowStep.WDI_LED_CheckFinish;
                        }
                        break;

                    case FlowStep.WDI_LED_CheckFinish:
                        {
                            if (!WDI_LED.isRun)
                            {
                                switch (WDI_LED.Step)
                                {
                                    case WdiLedStep.Finish:
                                        Result = eResponseResult.OK;
                                        Step = FlowStep.SendResponse;
                                        break;

                                    case WdiLedStep.Alm:
                                        Result = eResponseResult.ERR;
                                        Step = FlowStep.SendResponse;
                                        break;
                                }
                            }
                        }
                        break;

                    #endregion

                    #region Dark Field

                    case FlowStep.Dark_Field_CheckCMD:
                        {
                            switch (GetParam[1])
                            {
                                case "Pulsed_Output_Mode":
                                    Step = FlowStep.Dark_Field_PulseMode;
                                    break;

                                default:
                                    SaveLog("Command Match Fail", true);
                                    Result = eResponseResult.ERR;
                                    SendParam[9] = "Command Match Fail";
                                    Step = FlowStep.SendResponse;
                                    break;
                            }
                        }
                        break;

                    case FlowStep.Dark_Field_PulseMode:
                        {
                            int Channel = Convert.ToInt32(GetParam[2]);
                            int PulseWidth = Convert.ToInt32(GetParam[3]);
                            int TriggerDelay = Convert.ToInt32(GetParam[4]);
                            int Current = Convert.ToInt32(GetParam[5]);
                            int ReTriggerDelay = Convert.ToInt32(GetParam[6]);

                            Dark_Field.PulsedOutputMode(Channel, PulseWidth, TriggerDelay, Current, ReTriggerDelay);

                            Step = FlowStep.Dark_Field_CheckFinish;

                        }
                        break;


                    case FlowStep.Dark_Field_CheckFinish:
                        {
                            if (!Dark_Field.isRun)
                            {
                                switch (Dark_Field.Step)
                                {
                                    case CltFlowStep.Finish:
                                        Result = eResponseResult.OK;
                                        Step = FlowStep.SendResponse;
                                        break;

                                    case CltFlowStep.Alm:
                                        Result = eResponseResult.ERR;
                                        Step = FlowStep.SendResponse;
                                        break;
                                }
                            }
                        }
                        break;

                    #endregion

                    #region Revo                                               

                    case FlowStep.Revo_CheckCMD:
                        {
                            switch (GetParam[1])
                            {
                                case "Change_Lens":
                                    Step = FlowStep.Revo_Change_Lens;
                                    break;

                                default:
                                    SaveLog("Command Match Fail", true);
                                    Result = eResponseResult.ERR;
                                    SendParam[9] = "Command Match Fail";
                                    Step = FlowStep.SendResponse;
                                    break;
                            }
                        }
                        break;

                    case FlowStep.Revo_Change_Lens:
                        {
                            int LedIdx = Convert.ToInt32(GetParam[2]);
                            Revo.ChangeLens(LedIdx);
                            Step = FlowStep.Revo_CheckFinish;
                        }
                        break;


                    case FlowStep.Revo_CheckFinish:
                        {
                            if (!Revo.isRun)
                            {
                                switch (Revo.GetResponse)
                                {
                                    case Revo_Ctrl.Response.OK:
                                        Result = eResponseResult.OK;
                                        Step = FlowStep.SendResponse;
                                        break;

                                    case Revo_Ctrl.Response.Error:
                                        Result = eResponseResult.ERR;
                                        Step = FlowStep.SendResponse;
                                        break;
                                }
                            }
                        }
                        break;

                    #endregion


                    case FlowStep.SendResponse:
                        {
                            Svr.ReturnResponse(Result, SendParam[1], SendParam[2], SendParam[3], SendParam[4],
                                SendParam[5], SendParam[6], SendParam[7], SendParam[8], SendParam[9]);

                            bool isAlm = (Result == eResponseResult.ERR);

                            string ResponseStr = $"{Result}";

                            for (int i = 1; i <= 9; i++)
                            {
                                if (SendParam[i].Trim().Length > 0)
                                    ResponseStr += $",{SendParam[i]}";
                            }

                            SaveLog($"### Send Response : {ResponseStr}", isAlm);
                            IsGetRequest = false;
                        }
                        break;
                }
            }
        }

        private enum FlowStep
        {
            CheckType,

            WDI_AF_CheckCMD,
            WDI_AF_Home,
            WDI_AF_Abs_Move,
            WDI_AF_AF_On,
            WDI_AF_AF_Off,
            WDI_AF_Read_Pos,
            WDI_AF_Set_Substrate,
            WDI_AF_Get_Substrate,

            WDI_LED_CheckCMD,
            WDI_LED_Set_Mode,
            WDI_LED_Off,
            WDI_LED_CheckFinish,

            Dark_Field_CheckCMD,
            Dark_Field_PulseMode,
            Dark_Field_CheckFinish,

            Revo_CheckCMD,
            Revo_Change_Lens,
            Revo_CheckFinish,

            SendResponse,
        }
    }
}
