﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;


public class WDI_Led_Ctrl
{
    public event Action<string, bool> WriteLog;
    public event Action<bool> IsConnectEvent;

    private SerialPort My_SerialPort;

    private Response GetResponse = Response.None;
    private bool isProc = false;
    private bool isLedOpen = true;

    private WdiLedStep NowStep = WdiLedStep.Init;
    private WdiLedStep LastStep = WdiLedStep.Init;

    private int Para_Brightness = 0;
    private int Para_Mode = 0;

    private TimeManager TM = new TimeManager();

    public WdiLedStep Step
    {
        get
        {
            return NowStep;
        }
    }

    public bool isRun
    {
        get
        {
            return isProc;
        }
    }

    public bool LedOn
    {
        get
        {
            return isLedOpen;
        }
    }


    #region "RS232 Ctrl"

    public WDI_Led_Ctrl()
    {
        My_SerialPort = new SerialPort();
        My_SerialPort.DataReceived -= My_SerialPort_DataReceived;
        My_SerialPort.DataReceived += My_SerialPort_DataReceived;
    }

    private void My_SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
    {
        SerialPort sp = (SerialPort)sender;

        int bytes = sp.BytesToRead;
        byte[] buffer = new byte[bytes];
        sp.Read(buffer, 0, bytes);

        switch (buffer[0])
        {
            case 0x41: //ACK
                GetResponse = Response.OK;
                break;

            case 0x4E: //NACK
                GetResponse = Response.Error;
                break;
        }
    }

    private void SaveLog(string Log, bool isAlm = false)
    {
        WriteLog?.Invoke(Log, isAlm);
    }

    public bool Connect(int Comport, int Baudrate = 9600)
    {
        try
        {
            if (My_SerialPort.IsOpen)
            {
                My_SerialPort.Close();
            }

            //設定 Serial Port 參數                
            My_SerialPort.PortName = "Com" + Comport.ToString();
            My_SerialPort.BaudRate = Baudrate;
            My_SerialPort.DataBits = 8;
            My_SerialPort.StopBits = StopBits.One;

            if (!My_SerialPort.IsOpen)
            {
                //開啟 Serial Port
                My_SerialPort.Open();

                Thread.Sleep(100);
                Ping();
            }

            IsConnectEvent?.Invoke(true);
            return true;
        }
        catch (Exception ex)
        {
            SaveLog(ex.Message, true);
            IsConnectEvent?.Invoke(false);
            return false;
        }
    }

    public void Close()
    {
        try
        {
            My_SerialPort.Close();
        }
        catch (Exception ex)
        {
            SaveLog(ex.Message, true);
        }
    }

    private bool SendData(byte[] SendBuffer, bool isMergeData = false)
    {
        if (SendBuffer != null)
        {
            byte[] buffer = new byte[] { };
            if (isMergeData)
            {
                buffer = MergeData(SendBuffer);
            }
            else
            {
                buffer = SendBuffer;
            }

            try
            {
                GetResponse = Response.None;
                My_SerialPort.Write(buffer, 0, buffer.Length);
                return true;
            }
            catch (Exception ex)
            {
                // MessageBox.Show(ex.Message);
                SaveLog(ex.Message, true);
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    #endregion

    private byte[] MergeData(byte[] OriData)
    {
        //加入 0xFF
        byte[] TmpByte = new byte[OriData.Length + 1];
        TmpByte[0] = 0xFF;

        for (int i = 0; i < OriData.Length; i++)
        {
            TmpByte[i + 1] = OriData[i];
        }

        //加入 CRC
        byte CRC = CRC_8(TmpByte);
        byte[] ResultByte = new byte[TmpByte.Length + 1];

        for (int i = 0; i < TmpByte.Length; i++)
        {
            ResultByte[i] = TmpByte[i];
        }
        ResultByte[ResultByte.Length - 1] = CRC;

        //Show
        string ResultStr = string.Empty;
        for (int i = 0; i < ResultByte.Length; i++)
        {
            ResultStr += " 0x" + string.Format("{0:X2}", ResultByte[i]).ToUpper();
        }
        // MessageBox.Show(ResultStr);

        return ResultByte;
    }

    private byte CRC_8(byte[] buffer)
    {
        byte crc = 0;
        byte polynomial = 0x07;
        for (int j = 0; j < buffer.Length; j++)
        {
            crc ^= buffer[j];
            for (int i = 0; i < 8; i++)
            {
                if ((crc & 0x80) != 0)
                {
                    crc <<= 1;
                    crc ^= polynomial;
                }
                else
                {
                    crc <<= 1;
                }
            }
        }
        return crc;
    }

    #region "WDI Led Ctrl"

    public bool Ping() //開關LED
    {
        byte[] SendByte = new byte[] { 0x41 };

        return SendData(SendByte, false);
    }

    public bool SetOutput(bool IsLedOn) //開關LED
    {
        byte OnOff = 0x00;

        if (IsLedOn)
        {
            OnOff = 0xAA;
        }
        else
        {
            OnOff = 0xEE;
        }

        byte[] SendByte = new byte[] { 0x75, OnOff };

        return SendData(SendByte);
    }

    public bool SetOutputCurrent(int Brightness) //設定亮度
    {
        int RealValue = (Brightness * 1023) / 100;
        byte MSB = Convert.ToByte((RealValue & 0xFF00) >> 8); //高位
        byte LSB = Convert.ToByte(RealValue & 0x00FF); //低位

        byte[] SendByte = new byte[] { 0x61, MSB, LSB };

        return SendData(SendByte);
    }

    public bool SetDCMode()
    {
        byte[] SendByte = new byte[] { 0x72, 0x35 };
        return SendData(SendByte);
    }

    public bool SetPulseFollowMode()
    {
        byte[] SendByte = new byte[] { 0x79, 0x55 };
        return SendData(SendByte);
    }

    public void TurnOff()
    {
        if (!isProc)
        {
            isProc = true;
            NowStep = WdiLedStep.Send_CloseLed;
            Thread mThread = new Thread(this.Proc);
            mThread.Start();
        }
        else
        {
            isProc = false;
            TurnOff();
        }
    }

    public void SetMode(int ModeType, int Brightness) //0 = DC, 1 = Follow Mode
    {
        if (!isProc)
        {
            Para_Brightness = Brightness;
            Para_Mode = ModeType;

            isProc = true;
            NowStep = WdiLedStep.Send_OpenLed;
            Thread mThread = new Thread(this.Proc);
            mThread.Start();
        }
        else
        {
            isProc = false;
            SetMode(ModeType, Brightness);
        }
    }

    #endregion

    #region "Flow"

    public void Proc()
    {
        int RetryCnt = 1;
        //int ConfigRetryCnt = (Controller.SD.COC_WDI_LED_RetryCnt <= 1) ? 1 : Controller.SD.COC_WDI_LED_RetryCnt;
        //int WaitTime = (Controller.SD.COC_WDI_LED_WaitTime <= 1000) ? 1000 : Controller.SD.COC_WDI_LED_WaitTime;

        int ConfigRetryCnt = 3;
        int WaitTime = 1000;

        while (isProc)
        {
            switch (NowStep)
            {
                case WdiLedStep.Init:
                    {
                        //if (Controller.SD.COC_WDI_LED_TurnOff_Flag)
                        //{
                        //    RetryCnt = 1;
                        //    NowStep = WdiLedStep.Send_CloseLed;
                        //}
                        //else
                        //{
                        //    RetryCnt = 1;
                        //    NowStep = WdiLedStep.Send_OpenLed;
                        //}
                    }
                    break;

                case WdiLedStep.Send_CloseLed:
                    {
                        SaveLog("Send Requset = Close LED");
                        SetOutput(false);

                        LastStep = NowStep;
                        NowStep = WdiLedStep.Check_Response;
                        TM.SetDelay(WaitTime);
                    }
                    break;

                case WdiLedStep.Send_OpenLed:
                    {
                        SaveLog("Send Requset = Open LED");
                        SetOutput(true);

                        LastStep = NowStep;
                        NowStep = WdiLedStep.Check_Response;
                        TM.SetDelay(WaitTime);
                    }
                    break;

                case WdiLedStep.Send_SetBrightness:
                    {
                        SaveLog(string.Format($"Send Requset = Set Brightness({Para_Brightness}%)"));
                        SetOutputCurrent(Para_Brightness);

                        LastStep = NowStep;
                        NowStep = WdiLedStep.Check_Response;
                        TM.SetDelay(WaitTime);
                    }
                    break;

                case WdiLedStep.Send_SetMode:
                    {
                        if (Para_Mode == 0)
                        {
                            SaveLog("Send Requset = Set DC Mode");
                            SetDCMode();
                        }

                        if (Para_Mode == 1)
                        {
                            SaveLog("Send Requset = Set Pulse Follow Mode");
                            SetPulseFollowMode();
                        }

                        LastStep = NowStep;
                        NowStep = WdiLedStep.Check_Response;
                        TM.SetDelay(WaitTime);
                    }
                    break;

                case WdiLedStep.Check_Response:
                    {
                        if (GetResponse == Response.OK)
                        {
                            SaveLog("Get Response = OK");

                            if (LastStep == WdiLedStep.Send_SetMode)
                            {
                                isLedOpen = true;
                                NowStep = WdiLedStep.Finish;
                            }
                            else if (LastStep == WdiLedStep.Send_CloseLed)
                            {
                                isLedOpen = false;
                                NowStep = WdiLedStep.Finish;
                            }
                            else
                            {
                                NowStep = LastStep + 10;
                                RetryCnt = 1;
                            }
                        }
                        else if (GetResponse == Response.Error)
                        {
                            if (RetryCnt < ConfigRetryCnt)
                            {
                                RetryCnt++;

                                SaveLog($"Get Response = Error , Retry Cnt = {RetryCnt}", true);
                                NowStep = LastStep;
                            }
                            else
                            {
                                SaveLog("Get Response = Error", true);
                                NowStep = WdiLedStep.Alm;
                            }
                        }
                        else
                        {
                            if (TM.IsTimeOut())
                            {
                                if (RetryCnt < ConfigRetryCnt)
                                {
                                    RetryCnt++;

                                    SaveLog($"TimeOut , Retry Cnt = {RetryCnt}", true);
                                    NowStep = LastStep;
                                }
                                else
                                {
                                    SaveLog("TimeOut", true);
                                    NowStep = WdiLedStep.Alm;
                                }
                            }
                        }
                    }
                    break;

                case WdiLedStep.Finish:
                    {
                        //SaveLog("Finish");
                        isProc = false;
                    }
                    break;

                case WdiLedStep.Alm:
                    {
                        //SaveLog("Alm", true);
                        isProc = false;
                    }
                    break;
            }
        }
    }

    #endregion

    private enum CMD
    {
        DCMode,
        PulseFollowMode,
        LightOff,
    }

    private enum Response
    {
        None,
        OK,
        Error,
    }


}

public enum WdiLedStep
{
    Init = 0,

    Send_CloseLed = 10,

    Send_OpenLed = 20,

    Send_SetBrightness = 30,

    Send_SetMode = 40,

    Check_Response = 100,

    Finish = 500,
    Alm = 999,
}

