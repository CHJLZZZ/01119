﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AUO.SubSystemControl_String;


namespace OpticalControl
{
    public class Gardasoft_Light_Ctrl
    {
        //Client
        public event Action<string, bool> WriteLog;
        public event Action<bool> IsConnectEvent;

        private CControlManager Client = new CControlManager();
        private CResponseResult ResponseResult = new CResponseResult();
        private Thread CltThread;
        private CltFlowStep CltStep = CltFlowStep.Finish;
        private bool IsCltConnect = false;
        private bool isProc = false;
        private string Clt_SendPara = string.Empty;
        private string Clt_GetPara = string.Empty;

        //DelayTime
        public int DelayTime = 10000;

        protected void SaveLog(string Log, bool isAlm = false)
        {
            WriteLog?.Invoke($"{Log}", isAlm);
        }

        public bool isRun
        {
            get { return isProc; }
        }

        public CltFlowStep Step
        {
            get { return CltStep; }
        }

        public string ResponsePara
        {
            get { return Clt_GetPara; }
        }

        public Gardasoft_Light_Ctrl()
        {
            Client = new CControlManager();

            Client.ReceiveOccurError -= Client_ReceiveOccurError;
            Client.ReceiveOccurError += Client_ReceiveOccurError;

            Client.RemoteDisconnect -= Client_RemoteDisconnect;
            Client.RemoteDisconnect += Client_RemoteDisconnect;
        }


        public virtual void Close()
        {
            if (Client != null)
            {
                Client.Disconnect();
            }

            if (CltThread != null)
            {
                CltThread.Abort();
            }
        }

        public void Stop()
        {
            CltStep = CltFlowStep.Idle;
            isProc = false;

            if (CltThread != null)
            {
                CltThread.Abort();
            }

        }

        #region "Event"


        protected void Client_RemoteDisconnect()
        {
            IsConnectEvent(false);
            IsCltConnect = false;
            isProc = false;
        }

        protected void Client_ReceiveOccurError(string ErrMessage)
        {
            SaveLog($"Client Error - { ErrMessage}", true);
        }

        #endregion

        #region "Client"

        public bool CltConnect(string IP, int Port)
        {
            try
            {
                Client.Disconnect();

                Thread.Sleep(100);

                Client.CreateClient(IP, Port, 0, "Clt");
                IsCltConnect = true;
                IsConnectEvent(true);
                CltStep = CltFlowStep.Idle;

            }
            catch (Exception ex)
            {
                SaveLog($"{ex.Message}", true);
                IsCltConnect = false;
                IsConnectEvent(false);

            }

            return IsCltConnect;
        }


        public bool DoStep(string CMD)
        {
            try
            {
                if (!isProc)
                {
                    isProc = true;


                    Clt_SendPara = CMD;

                    CltStep = CltFlowStep.SendRequest;
                    CltThread = new Thread(this.CltFlow);
                    CltThread.Start();
                    return true;
                }
                else
                {
                    SaveLog($"Running", true);
                    return false;
                }
            }
            catch (Exception ex)
            {
                SaveLog($"DoStep Fail - {ex.Message}", true);
                return false;
            }
        }

        public virtual void CltFlow()
        {
            while (isProc)
            {
                switch (CltStep)
                {
                    case CltFlowStep.Idle:
                        break;

                    case CltFlowStep.SendRequest:
                        try
                        {
                            string Sendtxt = Clt_SendPara;

                            Client.PrepareAllRequest(Clt_SendPara);

                            SaveLog($"Send Request - {Sendtxt}");

                            if (DelayTime < 5000)
                            {
                                DelayTime = 5000;
                            }

                            ResponseResult = new CResponseResult();
                            ResponseResult = Client.SendRequest(DelayTime);
                            CltStep = CltFlowStep.CheckReturn;
                        }
                        catch (Exception ex)
                        {
                            SaveLog($"Send Request Fail - { ex.Message}", true);
                            CltStep = CltFlowStep.Alm;
                        }
                        break;

                    case CltFlowStep.CheckReturn:
                        if (ResponseResult.Responses[0] == "Timeout")
                        {
                            SaveLog($"TimeOut", true);
                            CltStep = CltFlowStep.Alm;
                        }
                        else
                        {
                            Clt_GetPara = ResponseResult.Responses[0];

                            if (isReadErrorMsg)
                            {
                                ErrorMsg = Clt_GetPara;
                                isReadErrorMsg = false;
                            }

                            SaveLog($"Get Response - {Clt_GetPara}");

                            CltStep = CltFlowStep.Finish;

                        }
                        break;

                    case CltFlowStep.Finish:
                        isProc = false;
                        break;

                    case CltFlowStep.Alm:
                        SaveLog($"Process Alm", true);
                        isProc = false;
                        break;
                }
            }
        }

        #endregion

        #region Function

        private bool isReadErrorMsg = false;
        public string ErrorMsg = string.Empty;
        public bool SaveSetting()
        {
            string CMD = "AW";
            return DoStep(CMD);
        }

        public bool SetTriggerMode(int Mode)
        {
            // FP0 All channels triggered individually
            // FP1 All channels triggered by input 0*
            // FP2 Channels 0 to 3 triggered from input 0, channels 4 to 7 triggered from input 4.

            string CMD = $"FP{Mode}";
            return DoStep(CMD);
        }

        public bool InternalTriggerMode(int Mode, int Period = 0)
        {
            //TT0 Use external triggers
            //TT1 Use internal trigger (defaults to 25Hz)
            //TT1,p Use internal trigger and set the period(um).

            string CMD = $"TT{Mode}";

            if (Period > 0)
            {
                CMD += $",{Period}";
            }

            return DoStep(CMD);
        }

        public bool SimulateInputTrigger(int Channel)
        {
            string CMD = $"TR{Channel}";

            return DoStep(CMD);
        }

        public bool ReadErrorMsg()
        {
            ErrorMsg = string.Empty;
            isReadErrorMsg = true;
            string CMD = $"GR";

            return DoStep(CMD);
        }

        public bool ContinuousOutputMode(int Channel, double Current)
        {
            string CMD = $"RS{Channel},{Current}";

            return DoStep(CMD);
        }

        public bool SwitchedOutputMode(int Channel, double Current)
        {
            string CMD = $"RW{Channel},{Current}";

            return DoStep(CMD);
        }

        public bool PulsedOutputMode(int Channel, int PulseWidth, int TriggerDelay, double Current, int ReTriggerDelay = 0)
        {
            // The pulse delay can be from approximately 3μs to 1 second
            // The pulse width can be any value from 1μs to 1 second.

            string CMD = $"RT{Channel},{PulseWidth},{TriggerDelay},{Current}";

            if (ReTriggerDelay > 0)
            {
                CMD += $",{ReTriggerDelay}";
            }

            return DoStep(CMD);
        }

        #endregion
    }

    public enum CltFlowStep
    {
        Idle = 0,

        SendRequest = 200,
        CheckReturn,

        Finish = 500,

        Alm,
    }
}
