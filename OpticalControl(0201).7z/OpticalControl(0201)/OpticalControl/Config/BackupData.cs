﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace OpticalControl
{
    public class BackupData
    {
        public BackupData()
        {
     
        }

        #region WDI AF

        public double WDI_AF_ZPos { get; set; }
        public int WDI_AF_LimitUpper { get; set; }
        public int WDI_AF_LimitLower { get; set; }
        public int WDI_AF_LightChannel { get; set; }
        public int WDI_AF_LightCurrent { get; set; }
        public int WDI_AF_LightuPWM { get; set; }

        #endregion

        #region WDI LED

        public int WDI_LED_Mode { get; set; }
        public int WDI_LED_Brightness { get; set; }

        #endregion

        #region 暗場

        public int Gardasoft_Channel { get; set; }
        public int Gardasoft_PulseWidth { get; set; }
        public int Gardasoft_TriggerDelay { get; set; }
        public int Gardasoft_OutputCurrent { get; set; }
        public int Gardasoft_ReTriggerDelay { get; set; }

        #endregion


        public void Create(BackupData clsRecipe, string filename)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(BackupData));
            TextWriter writer = new StreamWriter(filename);

            serializer.Serialize(writer, clsRecipe);
            writer.Close();
        }

        public BackupData Read(string filename)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(BackupData));
            FileStream fp = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BackupData Sfp = (BackupData)serializer.Deserialize(fp);
            fp.Close();

            return Sfp;
        }
    }



}
