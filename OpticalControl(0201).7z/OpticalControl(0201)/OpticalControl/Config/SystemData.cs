﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace OpticalControl
{
    public class SystemData
    {
        public SystemData()
        {
            Svr_IP = "127.0.0.1";
            Svr_Port = 5000;
            WDI_AF_Comport = 1;
            WDI_AF_MoveDelay = 1000;

            WDI_LED_ComPort = 2;
        }

        #region Server Setting

        [Category("0. Server 設定")]
        [Description("Server - IP")]
        [DisplayName("Server - IP")]
        public string Svr_IP { get; set; }

        [Category("0. Server 設定")]
        [Description("Server - Port")]
        [DisplayName("Server - Port")]
        public int Svr_Port { get; set; }

        #endregion

        #region WDI AF

        [Category("1. WDI AF 設定")]
        [Description("WDI AF - Comport")]
        [DisplayName("WDI AF - Comport")]
        public int WDI_AF_Comport { get; set; }

        [Category("1. WDI AF 設定")]
        [Description("WDI AF 移動後整定時間 (ms)")]
        [DisplayName("WDI AF - MoveDelay")]
        public int WDI_AF_MoveDelay { get; set; }

        #endregion

        #region WDI LED

        [Category("2. WDI LED 設定")]
        [Description("WDI LED - ComPort")]
        [DisplayName("WDI LED - ComPort")]
        public Int16 WDI_LED_ComPort { get; set; }

        #endregion

        #region 暗場

        [Category("3. 暗場光源 設定")]
        [Description("暗場光源 - IP")]
        [DisplayName("暗場光源 - IP")]
        public string DarkField_IP { get; set; }

        [Category("3. 暗場光源 設定")]
        [Description("暗場光源 - Port")]
        [DisplayName("暗場光源 - Port")]
        public int DarkField_Port { get; set; }

        #endregion

        #region Revo

        [Category("4. 鼻輪 設定")]
        [Description("鼻輪 - ComPort")]
        [DisplayName("鼻輪 - ComPort")]
        public Int16 Revo_ComPort { get; set; }

        #endregion

        public void Create(SystemData clsRecipe, string filename)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(SystemData));
            TextWriter writer = new StreamWriter(filename);

            serializer.Serialize(writer, clsRecipe);
            writer.Close();
        }

        public SystemData Read(string filename)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(SystemData));
            FileStream fp = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.ReadWrite);
            SystemData Sfp = (SystemData)serializer.Deserialize(fp);
            fp.Close();

            return Sfp;
        }
    }



}
