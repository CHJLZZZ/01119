﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OpticalControl
{
    static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {

            #region 檢查程式是否重複執行

            bool is_createdNew1;
            string mutexName1 = Process.GetCurrentProcess().ProcessName;
            Mutex mu1 = new Mutex(true, "Global\\" + mutexName1, out is_createdNew1);
            if (!is_createdNew1)
            {
                MessageBox.Show($"OpticalControl - {mutexName1} 重複開啟!! 請確認是否已開啟/未正常關閉(Ctrl+Alt+Del)");
                return;
            }

            #endregion

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
