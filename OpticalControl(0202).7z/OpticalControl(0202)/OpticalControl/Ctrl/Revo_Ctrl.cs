﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpticalControl
{
    public class Revo_Ctrl
    {
        private SerialPort My_SerialPort;
        public event Action<string, bool> WriteLog;
        public event Action<bool> IsConnectEvent;

        private Response _GetResponse = Response.None;
        private bool isReadStatus = false;
        private bool isProc = false;
        private int _OperationStatus = 0;
        private int _Communication = 0;
        private int _ConnectionStatus = 0;
        private int _Version = 0;
        private int _SensorStatus = 0;

        public Response GetResponse { get { return _GetResponse; } }
        public int OperationStatus { get { return _OperationStatus; } }
        public int Communication { get { return _Communication; } }
        public int ConnectionStatus { get { return _ConnectionStatus; } }
        public int Version { get { return _Version; } }
        public int SensorStatus { get { return _SensorStatus; } }
        public bool isRun { get { return isProc; } }

        public Revo_Ctrl()
        {
            My_SerialPort = new SerialPort();
            My_SerialPort.DataReceived -= My_SerialPort_DataReceived;
            My_SerialPort.DataReceived += My_SerialPort_DataReceived;
        }

        public bool Connect(int Comport, int Baudrate = 9600)
        {
            try
            {
                if (My_SerialPort.IsOpen)
                {
                    My_SerialPort.Close();
                }

                //設定 Serial Port 參數                
                My_SerialPort.PortName = "Com" + Comport.ToString();
                My_SerialPort.BaudRate = Baudrate;
                My_SerialPort.DataBits = 8;
                My_SerialPort.StopBits = StopBits.One;

                if (!My_SerialPort.IsOpen)
                {
                    //開啟 Serial Port
                    My_SerialPort.Open();
                }

                IsConnectEvent?.Invoke(true);
                return true;
            }
            catch (Exception ex)
            {
                SaveLog(ex.Message, true);
                IsConnectEvent?.Invoke(false);
                return false;
            }
        }

        public void Close()
        {
            try
            {
                My_SerialPort.Close();
            }
            catch (Exception ex)
            {
                SaveLog(ex.Message, true);

            }
        }

        private void SaveLog(string Log, bool isAlm = false)
        {
            WriteLog?.Invoke(Log, isAlm);
        }

        private bool SendData(byte[] SendBuffer, bool isMergeData = true)
        {
            if (SendBuffer != null)
            {
                isProc = false;

                byte[] buffer = SendBuffer;

                try
                {
                    _GetResponse = Response.None;
                    My_SerialPort.Write(buffer, 0, buffer.Length);
                    return true;
                }
                catch (Exception ex)
                {
                    // MessageBox.Show(ex.Message);
                    SaveLog(ex.Message, true);
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public bool ChangeLens(int Idx)
        {
            string[] LenIdx = { "A", "B", "C", "D" };
            string CMD = $"RWRMV{LenIdx[Idx]}\r\n";

            byte[] Datas = Encoding.ASCII.GetBytes(CMD);

            return SendData(Datas);
        }

        public bool ChangeStop()
        {
            string CMD = $"RWRSTP\r\n";

            byte[] Datas = Encoding.ASCII.GetBytes(CMD);

            return SendData(Datas);
        }

        public bool ReadStatus()
        {
            string CMD = $"RRDSTU\r\n";

            byte[] Datas = Encoding.ASCII.GetBytes(CMD);
            isReadStatus = true;
            return SendData(Datas);
        }

        private void My_SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            isProc = false;
            SerialPort sp = (SerialPort)sender;

            int bytes = sp.BytesToRead;
            byte[] buffer = new byte[bytes];
            sp.Read(buffer, 0, bytes);

            string result = System.Text.Encoding.UTF8.GetString(buffer);

            string Status = result.Substring(1, 2);

            switch (Status)
            {
                case "OK":
                    if (isReadStatus && result.Length > 10)
                    {
                        isReadStatus = false;

                        _OperationStatus = Convert.ToInt32(result.Substring(3, 1));
                        _Communication = Convert.ToInt32(result.Substring(7, 1));
                        _ConnectionStatus = Convert.ToInt32(result.Substring(8, 1));
                        _Version = Convert.ToInt32(result.Substring(9, 1));
                        _SensorStatus = Convert.ToInt32(result.Substring(10, 1));

                        string LogInfo = $"OperationStatus = {_OperationStatus}, " +
                            $"Communication = {_Communication}, " +
                            $"ConnectionStatus = {_ConnectionStatus}, " +
                            $"Version = {_Version}, " +
                            $"SensorStatus = {_SensorStatus}";

                        SaveLog(LogInfo);
                    }
                    _GetResponse = Response.OK;

                    break;

                case "NG":
                    _GetResponse = Response.Error;
                    break;
            }
        }

        public enum Response
        {
            None,
            OK,
            Error,
        }
    }
}
